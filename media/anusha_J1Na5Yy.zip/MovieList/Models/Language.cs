namespace MovieList.Models
{
    public class Language
    {
        public string LanguageId { get; set; } = string.Empty;
        public string Name { get; set; } = string.Empty;
    }
}

